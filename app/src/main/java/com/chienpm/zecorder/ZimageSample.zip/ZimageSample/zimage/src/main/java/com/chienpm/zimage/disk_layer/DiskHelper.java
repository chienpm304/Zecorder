package com.chienpm.zimage.disk_layer;

import android.graphics.Bitmap;

import java.io.File;

class DiskHelper {
    public static boolean checkFileIsExisted(File localFile) {
        return false;
    }

    public static Bitmap loadBitmapImage(File localFile) {
        return null;
    }
}
